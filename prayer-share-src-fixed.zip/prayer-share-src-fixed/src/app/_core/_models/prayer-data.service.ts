import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { PrayerCard } from './prayer.models';
let idSeq = 3; let commentSeq = 3;
@Injectable({ providedIn: 'root' })
export class PrayerDataService {
  private readonly _cards$ = new BehaviorSubject<PrayerCard[]>([
    { id:1, title:'CJ — Tech School & Finances', detail:'Wisdom, steady work, and provision.', category:'Family', createdAt:new Date().toISOString(), comments:[{commentID:1, author:'Courtney', text:'Interview this Friday.', createdAt:new Date().toISOString()}] },
    { id:2, title:'AI Workshops — Reach CEOs', detail:'Clarity, helpful connections, God\'s favor.', category:'Work', createdAt:new Date().toISOString(), comments:[{commentID:2, author:'Courtney', text:'Scheduling Oct 2 session.', createdAt:new Date().toISOString()}] },
  ]);
  cards$ = this._cards$.asObservable();
  addCard(input:{title:string;detail:string;category:string}){
    const c = this._cards$.getValue();
    this._cards$.next([{ id:idSeq++, title:input.title.trim(), detail:input.detail.trim(), category:input.category||'General', createdAt:new Date().toISOString(), comments:[] }, ...c]);
  }
  deleteCard(id:number){ this._cards$.next(this._cards$.getValue().filter(v=>v.id!==id)); }
  updateTitle(id:number,title:string){ this._cards$.next(this._cards$.getValue().map(v=>v.id===id?{...v,title}:v)); }
  addComment(id:number, author:string, text:string){
    this._cards$.next(this._cards$.getValue().map(v=> v.id!==id? v : {...v, comments:[...v.comments, {commentID:commentSeq++, author, text, createdAt:new Date().toISOString()}]}));
  }
  deleteComment(cardID:number, commentID:number){
    this._cards$.next(this._cards$.getValue().map(v=> v.id!==cardID? v : {...v, comments:v.comments.filter(c=>c.commentID!==commentID)}));
  }
}
