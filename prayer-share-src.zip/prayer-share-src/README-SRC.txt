Prayer Share — MVP (Milestone 0) `src` folder
---------------------------------------------
1) Create a new Angular project (standalone):
   npm i -g @angular/cli
   ng new prayer-share --standalone --routing --style=css
   cd prayer-share

2) Replace the generated `src` with the contents of this ZIP.

3) Install deps and run:
   npm install
   ng serve -o