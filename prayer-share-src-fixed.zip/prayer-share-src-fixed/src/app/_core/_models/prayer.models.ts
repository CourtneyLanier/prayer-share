export interface PrayerComment { commentID:number; author:string; text:string; createdAt:string; inactiveStateID?:number; }
export interface PrayerCard { id:number; title:string; detail:string; category:string; createdAt:string; answered?:boolean; answerText?:string; comments:PrayerComment[]; }
